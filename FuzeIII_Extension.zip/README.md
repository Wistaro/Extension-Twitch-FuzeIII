# Chrome-Extension--Twitch-FuzeIII
Send a desktop notification when FuzeIII start a livestream on Twitch.tv 


Developed by Wistaro (javascript) and Voltext (HTML/CSS)
